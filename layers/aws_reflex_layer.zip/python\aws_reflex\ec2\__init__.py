from .factory import get_ec2_handler

__all__ = ["get_ec2_handler"]
